import serial

import collections

import matplotlib.animation as animation

from pylab import *
import tkinter as tk
from tkinter import ttk
from tkinter import *


# declarar varables
ventana = Tk()
ventana.title("Lab No. 1. Protocolo de comunicacion RS-232")
ventana.geometry("340x400")
baudRate = 250000
Samples = 200
sampleTime = 300
numData = 3
xmin = 0
xmax = Samples
ymin = [-7, -7, 0]
ymax = [7, 7, 2]
lines = []
data = []

# Crear caja de texto.
entry = ttk.Entry(ventana)


stm = serial.Serial('com3', baudrate=250000)
stm.setDTR(False)
stm.flushInput()

for i in range(3): #numdata
    data.append(collections.deque([0] * Samples, maxlen=Samples))
    lines.append(Line2D([], [], color='blue'))


def getSerialData(self,Samples,numData,stm, lines):
    stm.setDTR(False)
    stm.flushInput()
    s=stm.readline().decode("ascii")
    data_stm = stm.readline().strip().decode('ascii')
    valores = data_stm.split(sep=',')
    data[0].append(float(valores[0]))
    data[1].append(float(valores[1]))
    data[2].append(float(valores[2]))
    lines[0].set_data(range(Samples), data[0])
    lines[1].set_data(range(Samples), data[1])
    lines[2].set_data(range(Samples), data[2])

def s1():
    stm.write(b'a')
    fig = plt.figure(1)
    ax1 = fig.add_subplot(1, 3, 1, xlim=(xmin, xmax), ylim=(-10, 10))
    ax1.title.set_text('CONTROL')
    ax1.set_xlabel("TIEMPO")
    ax1.set_ylabel("VOLTAJE")
    ax1.add_line(lines[0])
    anim = animation.FuncAnimation(fig, getSerialData, fargs=(Samples, numData, stm, lines),
                                   interval=sampleTime)

    ax2 = fig.add_subplot(1, 3, 2, xlim=(xmin, xmax), ylim=(-1,2))
    ax2.title.set_text('ERROR')
    ax2.set_xlabel("TIEMPO")
    ax2.set_ylabel("VOLTAJE")
    ax2.add_line(lines[1])
    anim = animation.FuncAnimation(fig, getSerialData, fargs=(Samples, numData, stm, lines),
                                   interval=sampleTime)

    ax3 = fig.add_subplot(1, 3, 3, xlim=(xmin, xmax), ylim=(ymin[2], 5))
    ax3.title.set_text('SALIDA')
    ax3.set_xlabel("TIEMPO")
    ax3.set_ylabel("VOLTAJE")
    ax3.add_line(lines[2])
    anim = animation.FuncAnimation(fig, getSerialData, fargs=(Samples, numData, stm, lines),
                                   interval=sampleTime)
    fig.set_figheight(9)
    fig.set_figwidth(15)
    plt.show()
def s2():
    stm.write(b'b')
    fig = plt.figure(1)
    ax1 = fig.add_subplot(1, 3, 1, xlim=(xmin, xmax), ylim=(-1, 1))
    ax1.title.set_text('CONTROL')
    ax1.set_xlabel("TIEMPO")
    ax1.set_ylabel("VOLTAJE")
    ax1.add_line(lines[0])
    anim = animation.FuncAnimation(fig, getSerialData, fargs=(Samples, numData, stm, lines),
                                   interval=sampleTime)

    ax2 = fig.add_subplot(1, 3, 2, xlim=(xmin, xmax), ylim=(-0.05, 0.05))
    ax2.title.set_text('ERROR')
    ax2.set_xlabel("TIEMPO")
    ax2.set_ylabel("VOLTAJE")
    ax2.add_line(lines[1])
    anim = animation.FuncAnimation(fig, getSerialData, fargs=(Samples, numData, stm, lines),
                                   interval=sampleTime)

    ax3 = fig.add_subplot(1, 3, 3, xlim=(xmin, xmax), ylim=(0, 5))
    ax3.title.set_text('SALIDA')
    ax3.set_xlabel("TIEMPO")
    ax3.set_ylabel("VOLTAJE")
    ax3.add_line(lines[2])
    anim = animation.FuncAnimation(fig, getSerialData, fargs=(Samples, numData, stm, lines),
                                   interval=sampleTime)
    fig.set_figheight(9)
    fig.set_figwidth(15)
    plt.show()
def s3():
    valor = entry.get()
    d = stm.write(valor.encode())
    print(d)


botonS1 = Button(ventana, text="Escalon", background="blue", command=s1)
botonS1.place(x=10, y=10)
botonS1.config(width="45", height="7")
ventana.config(width=300, height=200)


# Posicionarla en la ventana.
entry.place(x=100, y=150)


botonS2 = Button(ventana, text="Rampa", background="green", command=s2)
botonS2.place(x=10, y=200)  # Boton sensor 1
botonS2.config(width="45", height="7")

botonS3 = Button(ventana, text="Enviar", background="white", command=s3)
botonS3.place(x=240, y=150)  # Boton sensor 1
botonS3.config(width="7", height="1")

ventana.configure(background="gray")
ventana.mainloop()
stm.close()  # cerrar puerto serial/ close serial port